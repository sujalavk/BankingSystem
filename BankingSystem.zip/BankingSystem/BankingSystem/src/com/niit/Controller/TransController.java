package com.niit.Controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.niit.Model.Transaction;
import com.niit.dao.TransactionDAOImpl;


@WebServlet("/transController")
public class TransController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransController() {
     
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		TransactionDAOImpl tn=new 	TransactionDAOImpl();
		Transaction t=new Transaction();
		t.setFromacct(request.getParameter("sender"));
		t.setToacct(request.getParameter("receiver"));
		java.sql.Date date=(java.sql.Date) new Date();
		t.setTransactiondate(date);
		tn.createTransaction(t);
	}

}
