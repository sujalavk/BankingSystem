package com.niit.dao;

import com.niit.Model.Account;
import com.niit.Model.Transaction;

public interface TransactionDAO {
	public boolean createTransaction(Transaction t);
	public boolean updatTransaction(Transaction t);
	
}
