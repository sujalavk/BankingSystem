package com.niit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.niit.Config.Dbconfig;
import com.niit.Model.Account;
import com.niit.Model.Transaction;

public class TransactionDAOImpl implements TransactionDAO{
	static Connection con = null;
	
	
	public TransactionDAOImpl() {
	con=Dbconfig.Dbconnection();
	}

	@Override
	public boolean createTransaction(Transaction t) {
		

	
		
			try {
				PreparedStatement ps = con.prepareStatement("INSERT INTO Transaction VALUES (?,?,?,?,?)");
				ps.setString(1,t.getTransId());

				ps.setString(2,t.getTrantype() );
				ps.setString(3, t.getFromacct());
				ps.setString(4, t.getToacct());
				ps.setDate(5, t.getTransactiondate());
				
				int i = ps.executeUpdate();
				if (i > 0) {
					System.out.println("transcation details  inserted successful");

					return true;

				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			return false;
		}

	@Override
	public boolean updatTransaction(Transaction t) {
		// TODO Auto-generated method stub
		return false;
	}
		
	

}
