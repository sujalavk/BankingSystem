package com.niit.dao;

import com.niit.Model.Account;

public class AccountDAOImpl implements AccountDAO{

	@Override
	public boolean AddAccount(Account ac) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updatAccount(Account ac) {
	
		return false;
	}

	@Override
	public String getgridcharacter(String GridCharacter) {
	
		return null;
	}

}
