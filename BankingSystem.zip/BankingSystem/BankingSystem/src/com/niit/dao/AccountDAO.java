package com.niit.dao;

import com.niit.Model.Account;

public interface AccountDAO {
	public boolean AddAccount(Account ac);
	public boolean updatAccount(Account ac);
	public String getgridcharacter(String GridCharacter);
	


}
