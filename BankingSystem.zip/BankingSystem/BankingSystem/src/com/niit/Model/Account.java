package com.niit.Model;

public class Account {

	String accountNo;
	double balance;
	String gridcharacters;
	
	public String getGridcharacters() {
		return gridcharacters;
	}
	public void setGridcharacters(String gridcharacters) {
		this.gridcharacters = gridcharacters;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	

}
