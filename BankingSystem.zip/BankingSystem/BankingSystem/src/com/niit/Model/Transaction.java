package com.niit.Model;

import java.util.Date;

public class Transaction {
	String transId;
	String trantype;
	String fromacct;
	String toacct;
	java.sql.Date transactiondate;
	
	
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public String getTrantype() {
		return trantype;
	}
	public void setTrantype(String trantype) {
		this.trantype = trantype;
	}
	public String getFromacct() {
		return fromacct;
	}
	public void setFromacct(String fromacct) {
		this.fromacct = fromacct;
	}
	public String getToacct() {
		return toacct;
	}
	public void setToacct(String toacct) {
		this.toacct = toacct;
	}
	public java.sql.Date getTransactiondate() {
		return transactiondate;
	}
	public void setTransactiondate(java.sql.Date transactiondate) {
		this.transactiondate = transactiondate;
	}
	

}
