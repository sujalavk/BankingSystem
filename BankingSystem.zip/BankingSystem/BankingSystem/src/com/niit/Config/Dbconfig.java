package com.niit.Config;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dbconfig {
	static public Connection Dbconnection()
	{
		Connection con=null;
		try{  
			Class.forName("com.");  
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/Banking");  
			}
		catch(Exception e)
		{ 
			System.out.println(e);
		
		}
			  return con;
			  
		
	}

}
